## Admin/pemilik (1)
- Daftar kamar
- Daftar poliklinik
- profil dokter
- pendaftaran online
- report
- pengguna
- informasi rumah sakit


## Adm Rumah sakit (2)
- informasi rumah sakit
-  Daftar kamar (mengatur ketersediaan nya saja)
-  profil dokter
-  pendaftaran online



## Pasien (3)
- informasi rumah sakit
- Daftar kamar
- Daftar poliklinik
- profil dokter
- pendaftaran online
- riwayat medis 
- jadwal saya

