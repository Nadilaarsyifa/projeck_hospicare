<?php
$conn = mysqli_connect("localhost", "root", "", "db_hospicare");
if (!$conn) {
    echo "gagal koneksi";
}
?>