<div class="col-lg-9 mt-2" style="height:700px;">

    <div class="container mt-3">
        <h2 class="text-center">Pilih Jenis pelayanan</h2>
        <div class="row mt-4">
            <div class="col-md-5">
                <div class="card">
                    <img src="assets/img/vip (6)_1721299681.jpeg" class="card-img-top" alt="Kamar Semi VIP">
                    <div class="card-body">
                        <h5 class="card-title">Rawat Inap</h5>
                        <p class="card-text"> HospiCare akan memberikan Anda akses ke perawatan medis terbaik dari tim dokter berpengalaman dan terlatih untuk memberikan perawatan berkualitas tinggi untuk memastikan pemulihan Anda optimal</p>
                        <a href="daftarinap" class="btn btn-primary" style="background-color: rgb(2, 139, 44)">Daftar</a>
                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <div class="card">
                    <img src="assets/img/THT.jpeg" class="card-img-top" alt="Kamar Semi VIP">
                    <div class="card-body">
                        <h5 class="card-title">Rawat Jalan</h5>
                        <p class="card-text">HospiCare memberikan perawatan medis berkualitas tinggi dengan perhatian khusus. kami siap membantu Anda dengan berbagai kebutuhan kesehatan, dari pemeriksaan rutin hingga terapi khusus</p>
                        <a href="daftarjalan" class="btn btn-primary" style="background-color: rgb(2, 139, 44)">Daftar</a>
                    </div>
                </div>
            </div>

        </div>
    </div>